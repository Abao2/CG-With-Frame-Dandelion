#include "object.h"

#include <iostream>
#include <array>
#include <optional>

#ifdef _WIN32
#include <Windows.h>
#endif
#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <fmt/format.h>

#include "../utils/math.hpp"
#include "../utils/ray.h"
#include "../simulation/solver.h"
#include "../utils/logger.h"

using Eigen::Matrix4f;
using Eigen::Quaternionf;
using Eigen::Vector3f;
using std::array;
using std::make_unique;
using std::optional;
using std::string;
using std::vector;

bool Object::BVH_for_collision   = false;
size_t Object::next_available_id = 0;
std::function<KineticState(const KineticState&, const KineticState&)> Object::step =
    forward_euler_step;

Object::Object(const string& object_name)
    : name(object_name), center(0.0f, 0.0f, 0.0f), scaling(1.0f, 1.0f, 1.0f),
      rotation(1.0f, 0.0f, 0.0f, 0.0f), velocity(0.0f, 0.0f, 0.0f), force(0.0f, 0.0f, 0.0f),
      mass(1.0f), BVH_boxes("BVH", GL::Mesh::highlight_wireframe_color)
{
    visible  = true;
    modified = false;
    id       = next_available_id;
    ++next_available_id;
    bvh                      = make_unique<BVH>(mesh);
    const string logger_name = fmt::format("{} (Object ID: {})", name, id);
    logger                   = get_logger(logger_name);
}

Matrix4f Object::model()
{
    //Scaling Matrix
    Matrix4f Scaling = Matrix4f::Identity();
    Scaling(0,0) = scaling.x();
    Scaling(1,1) = scaling.y();
    Scaling(2,2) = scaling.z();

    //Rotation Matrix
    const Quaternionf& r = rotation;
    auto [x_angle, y_angle, z_angle] = quaternion_to_ZYX_euler(r.w(), r.x(),r.y(), r.z());
// Then construct the rotation matrix with euler angles.

    float theta_x = radians(x_angle);
    float theta_y = radians(y_angle);
    float theta_z = radians(z_angle);

    //Rz
    Matrix4f Rz;
    Rz << std::cos(theta_z), -std::sin(theta_z), 0, 0,
          std::sin(theta_z),  std::cos(theta_z), 0, 0,
          0,                 0,                 1, 0,
          0,                 0,                 0, 1;

    //Ry
    Matrix4f Ry;
    Ry << std::cos(theta_y), 0, std::sin(theta_y), 0,
          0,                 1, 0,                 0,
         -std::sin(theta_y), 0, std::cos(theta_y), 0,
          0,                 0, 0,                 1;

    //Rx
    Matrix4f Rx;
    Rx << 1, 0,                 0,                0,
          0, std::cos(theta_x), -std::sin(theta_x), 0,
          0, std::sin(theta_x),  std::cos(theta_x), 0,
          0, 0,                 0,                1;

    Matrix4f Rotation = Rx * Ry * Rz;

    //Center Matrix
    Matrix4f Center = Matrix4f::Identity();
    Center(0,3) = center.x();
    Center(1,3) = center.y();
    Center(2,3) = center.z();

    //Transformation Matrix
    Matrix4f Trans = Center * Rotation * Scaling;


    return Trans;
}
void Object::update(vector<Object*>& all_objects)
{
    // 首先调用 step 函数计下一步该物体的运动学状态。
    KineticState current_state{center, velocity, force / mass};
    KineticState next_state = step(prev_state, current_state);
    // 将物体的位置移动到下一步状态处，但暂时不要修改物体的速度。
    center = next_state.position;
    // 遍历 all_objects，检查该物体在下一步状态的位置处是否会与其他物体发生碰撞。
    for (auto object : all_objects) {
        // 检测该物体与另一物体是否碰撞的方法是：
        // 遍历该物体的每一条边，构造与边重合的射线去和另一物体求交，如果求交结果非空、
        // 相交处也在这条边的两个端点之间，那么该物体与另一物体发生碰撞。
        // 请时刻注意：物体 mesh 顶点的坐标都在模型坐标系下，你需要先将其变换到世界坐标系。
        if( object->id == this->id )    continue;
        for (size_t i = 0; i < mesh.edges.count(); ++i) {
            array<size_t, 2> v_indices = mesh.edge(i);
            // v_indices 中是这条边两个端点的索引，以这两个索引为参数调用 GL::Mesh::vertex
            // 方法可以获得它们的坐标，进而用于构造射线。

            Vector3f v1 = mesh.vertex(v_indices[0]);
            Vector3f v2 = mesh.vertex(v_indices[1]);

            Eigen::Vector4f hv1 = {v1.x(), v1.y(), v1.z(), 1.0f};
            Eigen::Vector4f hv2 = {v2.x(), v2.y(), v2.z(), 1.0f};

            //get world coordinate
            //model()是this object的模型矩阵
            hv1 = model() * hv1;
            hv2 = model() * hv2;
            hv1 /= hv1.w();
            hv2 /= hv2.w();
            v1 = {hv1.x(), hv1.y(), hv1.z()};
            v2 = {hv2.x(), hv2.y(), hv2.z()};
            //generate ray
            Ray ray(v1, (v2-v1).normalized());
            //object->model() correspond to object inside the loop' model matrix
            //i.e. object to be detected
            std::optional<Intersection> intersection_opt = naive_intersect(ray, object->mesh, object->model());
            // 根据求交结果，判断该物体与另一物体是否发生了碰撞。
            if(intersection_opt.has_value()) {
                //have intersection
                Intersection intersection = intersection_opt.value();
                float t = intersection.t;
                float distance = (v2-v1).norm();
                if(t >= 0 && t <= distance) {
                    // 如果发生碰撞，按动量定理计算两个物体碰撞后的速度，并将下一步状态的位置设为
                    // current_state.position ，以避免重复碰撞。
                    // 完全弹性碰撞
                    //std::cout << "Collision detected!" << std::endl;
                    next_state.position = current_state.position;
                    if((next_state.velocity - object->velocity).dot(intersection.normal) == 0)    continue;
                    float momentum = (next_state.velocity - object->velocity).dot(intersection.normal);
                    momentum = momentum * (-2.0f) / (1.0f / mass + 1.0f / object->mass);
                    next_state.velocity = next_state.velocity + momentum / mass * intersection.normal;
                    object->velocity = object->velocity - momentum / object->mass * intersection.normal;
                    //更新状态
                    //center = current_state.position;

                    #ifdef DEBUG
                        std::cout << "Momentum: " << momentum << std::endl;
                        std::cout << "Object velocity: " << object->velocity << std::endl;
                        std::cout << "t: " << t << "   distance: " << distance << std::endl;
                        std::cout << "Next Velocity: " << std::endl << next_state.velocity << std::endl << " Normal: " << std::endl << intersection.normal << std::endl;
                    #endif

                    Vector3f temp = next_state.velocity;
                    next_state = step(current_state, next_state);
                    next_state.velocity = temp;
                    break;
                }
            }
        }
    }
    // 将上一步状态赋值为当前状态，并将物体更新到下一步状态。
    prev_state = current_state;
    center = next_state.position;
    velocity = next_state.velocity;
}

void Object::render(const Shader& shader, WorkingMode mode, bool selected)
{
    if (modified) {
        mesh.VAO.bind();
        mesh.vertices.to_gpu();
        mesh.normals.to_gpu();
        mesh.edges.to_gpu();
        mesh.edges.release();
        mesh.faces.to_gpu();
        mesh.faces.release();
        mesh.VAO.release();
    }
    modified = false;
    // Render faces anyway.
    unsigned int element_flags = GL::Mesh::faces_flag;
    if (mode == WorkingMode::MODEL) {
        // For *Model* mode, only the selected object is rendered at the center in the world.
        // So the model transform is the identity matrix.
        shader.set_uniform("model", I4f);
        shader.set_uniform("normal_transform", I4f);
        element_flags |= GL::Mesh::vertices_flag;
        element_flags |= GL::Mesh::edges_flag;
    } else {
        Matrix4f model = this->model();
        shader.set_uniform("model", model);
        shader.set_uniform("normal_transform", (Matrix4f)(model.inverse().transpose()));
    }
    // Render edges of the selected object for modes with picking enabled.
    if (check_picking_enabled(mode) && selected) {
        element_flags |= GL::Mesh::edges_flag;
    }
    mesh.render(shader, element_flags);
}

void Object::rebuild_BVH()
{
    bvh->recursively_delete(bvh->root);
    bvh->build();
    BVH_boxes.clear();
    refresh_BVH_boxes(bvh->root);
    BVH_boxes.to_gpu();
}

void Object::refresh_BVH_boxes(BVHNode* node)
{
    if (node == nullptr) {
        return;
    }
    BVH_boxes.add_AABB(node->aabb.p_min, node->aabb.p_max);
    refresh_BVH_boxes(node->left);
    refresh_BVH_boxes(node->right);
}
