#include "ray.h"

#include <iostream>
#include <cmath>
#include <array>

#include <Eigen/Dense>
#include <spdlog/spdlog.h>

#include "../utils/math.hpp"

using Eigen::Matrix3f;
using Eigen::Matrix4f;
using Eigen::Vector2f;
using Eigen::Vector3f;
using Eigen::Vector4f;
using std::numeric_limits;
using std::optional;
using std::size_t;

constexpr float infinity = 1e5f;
constexpr float eps      = 1e-5f;

Intersection::Intersection() : t(numeric_limits<float>::infinity()), face_index(0)
{
}

Ray generate_ray(int width, int height, int x, int y, Camera& camera, float depth)
{
    // these lines below are just for compiling and can be deleted
    (void)width;
    (void)height;
    (void)x;
    (void)y;
    (void)depth;
    // these lines above are just for compiling and can be deleted


    // The ratio between the specified plane (width x height)'s depth and the image plane's depth.
    
    // Transfer the view-space position to world space.
    Vector3f world_pos;
    return {camera.position, (world_pos - camera.position).normalized()};
}

optional<Intersection> ray_triangle_intersect(const Ray& ray, const GL::Mesh& mesh, size_t index)
{
    // these lines below are just for compiling and can be deleted
    (void)ray;
    (void)mesh;
    (void)index;
    // these lines above are just for compiling and can be deleted
    Intersection result;
    
    if (result.t - infinity < -eps) {
        return result;
    } else {
        return std::nullopt;
    }
}

optional<Intersection> naive_intersect(const Ray& ray, const GL::Mesh& mesh, const Matrix4f model)
{
    Intersection result;
    result.t = std::numeric_limits<float>::infinity();
    for (size_t i = 0; i < mesh.faces.count(); ++i) {
        // Vertex a, b and c are assumed to be in counterclockwise order.
        Vector4f a = {mesh.vertex(mesh.face(i)[0]).x(), mesh.vertex(mesh.face(i)[0]).y(), mesh.vertex(mesh.face(i)[0]).z(), 1.0f};
        Vector4f b = {mesh.vertex(mesh.face(i)[1]).x(), mesh.vertex(mesh.face(i)[1]).y(), mesh.vertex(mesh.face(i)[1]).z(), 1.0f};
        Vector4f c = {mesh.vertex(mesh.face(i)[2]).x(), mesh.vertex(mesh.face(i)[2]).y(), mesh.vertex(mesh.face(i)[2]).z(), 1.0f};
    
        // Transform the vertices to world space.
        a = model * a;
        b = model * b;
        c = model * c;

        a /= a.w();
        b /= b.w();
        c /= c.w();
        //fetch 3D coordinates
        Vector3f v_a = {a.x(), a.y(), a.z()};
        Vector3f v_b  = {b.x(), b.y(), b.z()};
        Vector3f v_c  = {c.x(), c.y(), c.z()};

        // Construct matrix A = [d, a - b, a - c] and solve Ax = (a - origin)
        Vector3f edge_ba = v_a - v_b;
        Vector3f edge_ca = v_a - v_c;
        Eigen::Matrix3f A;
        //ray.direction = ray.direction.normalized();
        A.col(0) = ray.direction.normalized();
        A.col(1) = edge_ba;
        A.col(2) = edge_ca;
        // Matrix A is not invertible, indicating the ray is parallel with the triangle.
        float det = A.determinant();
        if (std::fabs(det) < eps) {
            continue;
        }
        Vector3f vec_b = v_a - ray.origin;
        Eigen::ColPivHouseholderQR<Eigen::Matrix3f> qr(A);
        Vector3f x = qr.solve(vec_b);
        float alpha = x.y();
        float beta  = x.z();
        float gamma = 1.0f - alpha - beta;
        //auto [alpha, beta, gamma] = [x.y(), x.z(), 1.0f - x.y() - x.z()];
        // Test if alpha, beta and gamma are all between 0 and 1.
        if (alpha >= 0 && beta >= 0 && gamma >= 0) {
            float t = x.x(); // intersection's t
            if(t < eps) continue;        //t < 0
            if(t < result.t) {
                result.t = t;
                std::cout << "t = " << t << std::endl;
                result.normal = ((edge_ba).cross(edge_ca)).normalized();
                Vector3f bary_coord = {alpha, beta, gamma};
                result.barycentric_coord = bary_coord;
                result.face_index = i;
            }
        }
    }
    // Ensure result.t is strictly less than the constant `infinity`.
    if (result.t < std::numeric_limits<float>::infinity()) {
        #ifdef DEBUG
            std::cout << "Crashed!\n" << std::endl;
            std::cout << "Result.t = " << result.t << std::endl;
            std::cout << "result.t - infinity" << result.t - infinity << std::endl;
        #endif
        return result;
    }else{
        //std::cout << "Result.t = " << result.t << std::endl;
        //std::cout << "result.t - infinity" << result.t - infinity << std::endl;
    }
    // nan intersection
    return std::nullopt;
}
