#include "rasterizer_renderer.h"
#include "../utils/math.hpp"
#include <cstdio>

#ifdef _WIN32
#undef min
#undef max
#endif

using Eigen::Vector3f;
using Eigen::Vector4f;

// vertex shader    1、将顶点坐标变换到投影平面     2、再进行视口变换将法线向量变换到相机坐标系用于后续插值。
VertexShaderPayload vertex_shader(const VertexShaderPayload& payload)
{
    VertexShaderPayload output_payload = payload;

    // Vertex position transformation
    //模型坐标系 -> NDC 
    output_payload.viewport_position = (Uniforms::MVP * output_payload.world_position);
    //透视除法
    output_payload.viewport_position /= output_payload.viewport_position.w();

    // Viewport transformation

    // NDC -> 屏幕坐标系
    output_payload.viewport_position.x() = output_payload.viewport_position.x() * Uniforms::width * 0.5f + Uniforms::width * 0.5f;
    output_payload.viewport_position.y() = output_payload.viewport_position.y() * Uniforms::height * 0.5f + Uniforms::height * 0.5f;

    // Vertex normal transformation
    output_payload.normal = (Uniforms::inv_trans_M * Vector4f(output_payload.normal.x(), output_payload.normal.y(), output_payload.normal.z(), 0.f)).head<3>();
    output_payload.normal.normalized();
    return output_payload;
}

Vector3f phong_fragment_shader(const FragmentShaderPayload& payload, const GL::Material& material,
                               const std::list<Light>& lights, const Camera& camera)
{
    Vector3f result = {0, 0, 0};

    // ka,kd,ks can be got from material.ambient,material.diffuse,material.specular
    Vector3f ka = material.ambient;
    Vector3f kd = material.diffuse;
    Vector3f ks = material.specular;
    // set ambient light intensity
    float shininess = material.shininess;
    // Ambient
    float ambient_intensity = 0.4f;
    Vector3f ambient = ka * ambient_intensity;
    result += ambient;
    for(const Light& light : lights){
        // normal vector
        Vector3f normal = payload.world_normal.head<3>();
        // Light Direction
        Vector3f light_direction = (light.position - payload.world_pos);
        float distance = light_direction.norm();
        light_direction.normalize();
        // View Direction
        Vector3f view_direction = (camera.position - payload.world_pos).normalized();
        // Half Vector
        Vector3f half_vec = (light_direction + view_direction).normalized();
        // Light Attenuation
        float attenuated_light = light.intensity / (distance * distance);
        // Diffuse
        Vector3f diffuse = kd * attenuated_light * std::max(0.0f, payload.world_normal.dot(light_direction));
        // Specular
        Vector3f specular = ks * attenuated_light *
                std::pow(std::max(0.0f, normal.dot(half_vec)),
                shininess);
        result +=  diffuse + specular;
    }
    // set rendering result max threshold to 255
    if(result.x() > 1.0f)  result.x() = 1.0f; 
    if(result.y() > 1.0f)  result.y() = 1.0f; 
    if(result.z() > 1.0f)  result.z() = 1.0f; 
    return result * 255.f;
}
