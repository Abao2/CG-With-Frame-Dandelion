#include <array>
#include <limits>
#include <tuple>
#include <vector>
#include <algorithm>
#include <cmath>
#include <mutex>

#include <Eigen/Core>
#include <Eigen/Geometry>
#include <spdlog/spdlog.h>

#include "rasterizer.h"
#include "triangle.h"
#include "../utils/math.hpp"

using Eigen::Matrix4f;
using Eigen::Vector2i;
using Eigen::Vector3f;
using Eigen::Vector4f;
using std::fill;
using std::tuple;

void Rasterizer::worker_thread()        //光栅化线程：vertex(output) -> fragment
{
    while (true) {
        VertexShaderPayload payload[3];
        //VertexShaderPayload payload;
        Triangle triangle;
        {
            // printf("vertex_finish = %d\n vertex_shader_output_queue.size = %ld\n",
            // Context::vertex_finish, Context::vertex_shader_output_queue.size());

            //先判断是否完成
            if (Context::vertex_finish && Context::vertex_shader_output_queue.empty()) {
                Context::rasterizer_finish = true;
                return;
            }
            if (Context::vertex_shader_output_queue.size() < 3) {
                continue;
            }
            std::unique_lock<std::mutex> lock(Context::vertex_queue_mutex);
            if (Context::vertex_shader_output_queue.size() < 3) {
                continue;
            }
            for (int i = 0; i < 3; i++) {
                payload[i] = Context::vertex_shader_output_queue.front();
                Context::vertex_shader_output_queue.pop();
            }
        }//unlock
            //把三个顶点处理成三角形fragment
            for (size_t vertex_count = 0; vertex_count < 3; vertex_count++) {
                if (vertex_count == 0) {
                    triangle.world_pos[0]    = payload[vertex_count].world_position;
                    triangle.viewport_pos[0] = payload[vertex_count].viewport_position;
                    triangle.normal[0]       = payload[vertex_count].normal;
                } else if (vertex_count == 1) {
                    triangle.world_pos[1]    = payload[vertex_count].world_position;
                    triangle.viewport_pos[1] = payload[vertex_count].viewport_position;
                    triangle.normal[1]       = payload[vertex_count].normal;
                } else {
                    triangle.world_pos[2]    = payload[vertex_count].world_position;
                    triangle.viewport_pos[2] = payload[vertex_count].viewport_position;
                    triangle.normal[2]       = payload[vertex_count].normal;
                }
            }
        rasterize_triangle(triangle);
    }
}

float sign(Eigen::Vector2f p1, Eigen::Vector2f p2, Eigen::Vector2f p3)
{
    return (p1.x() - p3.x()) * (p2.y() - p3.y()) - (p2.x() - p3.x()) * (p1.y() - p3.y());
}

// 给定坐标(x,y)以及三角形的三个顶点坐标，判断(x,y)是否在三角形的内部
bool Rasterizer::inside_triangle(int x, int y, const Vector4f* vertices)
{
    Vector3f v[3];
    for (int i = 0; i < 3; i++) v[i] = {vertices[i].x(), vertices[i].y(), 1.0};

    float fx = static_cast<float>(x);
    float fy = static_cast<float>(y);

    //重心法求解
    auto [alpha, beta, gamma] = compute_barycentric_2d(fx, fy, vertices);
    return (alpha >= 0) && (beta >= 0) && (gamma >= 0);
}

// 给定坐标(x,y)以及三角形的三个顶点坐标，计算(x,y)对应的重心坐标[alpha, beta, gamma]
tuple<float, float, float> Rasterizer::compute_barycentric_2d(float x, float y, const Vector4f* v)
{
    float c1 = 0.f, c2 = 0.f, c3 = 0.f;
    //存储三角形顶点坐标
    Vector3f tri[3];
    for (int i = 0; i < 3; i++) tri[i] = {v[i].x(), v[i].y(), 1.0};

    //计算坐标
    // 计算 c3 (gamma)
    c3 = ((tri[0].y() - tri[1].y()) * x + (tri[1].x() - tri[0].x()) * y + tri[0].x() * tri[1].y() - tri[1].x() * tri[0].y()) /
         ((tri[0].y() - tri[1].y()) * tri[2].x() + (tri[1].x() - tri[0].x()) * tri[2].y() + tri[0].x() * tri[1].y() - tri[1].x() * tri[0].y());

    // 计算 c2 (beta)
    c2 = ((tri[0].y() - tri[2].y()) * x + (tri[2].x() - tri[0].x()) * y + tri[0].x() * tri[2].y() - tri[2].x() * tri[0].y()) /
         ((tri[0].y() - tri[2].y()) * tri[1].x() + (tri[2].x() - tri[0].x()) * tri[1].y() + tri[0].x() * tri[2].y() - tri[2].x() * tri[0].y());

    // 计算 c1 (alpha)
    c1 = 1 - c2 - c3;

    return {c1, c2, c3};
}

// 对顶点的某一属性插值
Vector3f Rasterizer::interpolate(float alpha, float beta, float gamma, const Eigen::Vector3f& vert1,
                                 const Eigen::Vector3f& vert2, const Eigen::Vector3f& vert3,
                                 const Eigen::Vector3f& weight, const float& Z)
{
    Vector3f interpolated_res;
    for (int i = 0; i < 3; i++) {
        interpolated_res[i] = alpha * vert1[i] / weight[0] + beta * vert2[i] / weight[1] +
                              gamma * vert3[i] / weight[2];
    }
    interpolated_res *= Z;
    return interpolated_res;
}

// 对当前三角形进行光栅化
void Rasterizer::rasterize_triangle(Triangle& t)
{

    // 存储w坐标
    Vector3f weight = {t.viewport_pos[0].w(), t.viewport_pos[1].w(), t.viewport_pos[2].w()};

    float x_min = t.viewport_pos[0].x();
    float x_max = t.viewport_pos[0].x();
    float y_min = t.viewport_pos[0].y();
    float y_max = t.viewport_pos[0].y();

    for(int i = 0; i < 3; i++) {
        x_min = std::max(0.0f, std::min(x_min, t.viewport_pos[i].x()));
        x_max = std::min(Context::frame_buffer.width-1.0f, std::max(x_max, t.viewport_pos[i].x()));
        y_min = std::max(0.0f, std::min(y_min, t.viewport_pos[i].y()));
        y_max = std::min(Context::frame_buffer.height-1.0f, std::max(y_max, t.viewport_pos[i].y()));
    }
    int int_x_min = static_cast<int>(x_min);
    int int_x_max = static_cast<int>(x_max);
    int int_y_min = static_cast<int>(y_min);
    int int_y_max = static_cast<int>(y_max);

    //遍历屏幕所有像素
    for(int i = int_x_min; i <= int_x_max; i++){
        for(int j = int_y_min; j <= int_y_max; j++){
                // if current pixel is in current triange:
            if(inside_triangle(i, j, t.viewport_pos)){

                // get barycentric coordinates
                float fi = static_cast<float>(i);
                float fj = static_cast<float>(j);
                auto [alpha, beta, gamma] = compute_barycentric_2d(fi, fj, t.viewport_pos);

                // compute Z_t
                float Z = 1 / (alpha / weight[0] + beta / weight[1] + gamma / weight[2]);

                //给片元各属性进行插值
                FragmentShaderPayload payload;
                payload.x = i;  payload.y = j;  //payload.color = NULL;

                // 1. interpolate depth(use projection correction algorithm)
                payload.depth = alpha * t.viewport_pos[0].z() / weight[0] + beta * t.viewport_pos[1].z() / weight[1] + gamma * t.viewport_pos[2].z() / weight[2];
                payload.depth *= Z;

                // 2. interpolate vertex positon & normal(use function:interpolate())
                payload.world_normal = interpolate(alpha, beta, gamma, t.normal[0], t.normal[1], t.normal[2], weight, Z);
                payload.world_normal.normalized();
                
                payload.world_pos = interpolate(alpha, beta, gamma, t.world_pos[0].head(3), t.world_pos[1].head(3), t.world_pos[2].head(3), weight, Z);
                
                // 3. push primitive into fragment queue
                std::unique_lock<std::mutex> lock(Context::rasterizer_queue_mutex);
                Context::rasterizer_output_queue.push(payload);
            }
        }
    }
}
